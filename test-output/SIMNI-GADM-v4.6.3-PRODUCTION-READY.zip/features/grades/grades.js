// ==========================================
// FILE: features/grades/grades.js
// Tujuan Pembelajaran, nilai, rekap dan buku induk.
// ==========================================

function tpId(tp) {
    return String(tp?.ID_mapel ?? tp?.learningObjectiveId ?? '').trim();
}

function gradeSubjectAllowed(subject) {
    const role = window.SIMNICurrentAccess?.role || null;
    return window.SIMNIAccessPolicy?.allowedSubject(role, subject) !== false;
}

function visibleLearningObjectives() {
    return state.mapelTP.filter((tp) => gradeSubjectAllowed(tp.mapel));
}

function applyGradeSubjectPolicy() {
    const role = window.SIMNICurrentAccess?.role || null;
    const vip = role === window.SIMNIAccessPolicy?.ROLES?.VIP;
    for (const id of ['filter-mapel-nilai', 'rekap-mapel-nilai', 'input-tp-mapel']) {
        const select = document.getElementById(id);
        if (!select) continue;
        [...select.options].forEach((option) => {
            const allowed = !option.value || gradeSubjectAllowed(option.value);
            option.hidden = !allowed;
            option.disabled = !allowed;
        });
        if (vip) select.value = 'PJOK';
    }
}

function getTPById(id) {
    return visibleLearningObjectives().find((tp) => tpId(tp) === String(id || '')) || null;
}

function legacyCodeUnique(code) {
    return state.mapelTP.filter((tp) => String(tp.kode_tp || '') === String(code || '')).length === 1;
}

function gradeMatchesTP(grade, tp) {
    const targetId = tpId(tp);
    if (grade?.learningObjectiveId && targetId) return String(grade.learningObjectiveId) === targetId;
    return legacyCodeUnique(tp?.kode_tp) && String(grade?.Deskripsi_TP || grade?.kode_tp || '') === String(tp?.kode_tp || '');
}

function gradeIdFor(student, tp) {
    const studentId = safeFirebaseKey(student?.ID_Siswa || `stu_${student?.NISN}`, 'studentId');
    const objectiveId = safeFirebaseKey(tpId(tp), 'learningObjectiveId');
    return `grade_${studentId}__${objectiveId}`;
}

function setNilaiTab(tab) {
    ['input', 'rekap', 'induk'].forEach((name) => {
        const button = document.getElementById(`tab-nilai-${name}`);
        if (button) button.className = `whitespace-nowrap px-4 py-2 border-b-2 text-sm font-bold ${tab === name ? 'border-primary text-primary' : 'border-transparent text-slate-500'}`;
        const panel = document.getElementById(`nilai-tab-${name}`);
        if (panel) panel.classList.toggle('hidden', tab !== name);
    });
    if (tab === 'rekap') updateRekapTPDropdown();
    if (tab === 'induk') renderBukuInduk();
}

function renderNilaiTPControls() {
    applyGradeSubjectPolicy();
    updateTPListModal();
    updateTPDropdown();
}

async function hapusTP(idMapel, kodeTP) {
    const tp = getTPById(idMapel);
    if (!tp) return toast('TP tidak ditemukan.', 'error');
    if (!confirm(`Hapus TP ${kodeTP}? Semua nilai pada TP ini di tahun aktif akan ikut dihapus.`)) return;

    const updates = { [`Mapel_TP/${safeFirebaseKey(tpId(tp), 'ID TP')}`]: null };
    state.nilaiTP.filter((grade) => gradeMatchesTP(grade, tp)).forEach((grade) => {
        const id = grade.ID_Nilai || gradeIdFor({ ID_Siswa: grade.ID_Siswa, NISN: grade.NISN }, tp);
        updates[`Nilai_TP/${safeFirebaseKey(id, 'ID nilai')}`] = null;
    });
    const result = await dbUpdate(updates);
    if (result?.ok) toast('TP dan nilai terkait berhasil dihapus.', 'success');
}

function updateTPListModal() {
    const list = document.getElementById('list-tp-modal');
    if (!list) return;
    list.replaceChildren();
    visibleLearningObjectives().forEach((tp) => {
        const row = document.createElement('div');
        row.className = 'bg-slate-50 p-2 rounded border border-slate-200 mb-2 flex justify-between items-start';
        const content = document.createElement('div'); content.className = 'flex-1';
        const code = document.createElement('span'); code.className = 'font-bold text-xs text-primary bg-indigo-50 px-2 py-0.5 rounded'; code.textContent = tp.kode_tp || '';
        const meta = document.createElement('span'); meta.className = 'text-[10px] text-slate-500 uppercase font-bold ml-1'; meta.textContent = `${tp.mapel || ''} Smt.${tp.semester || ''}`;
        const desc = document.createElement('p'); desc.className = 'text-xs mt-1 text-slate-700'; desc.textContent = tp.deskripsi_tp || '';
        content.append(code, meta, desc);
        const button = document.createElement('button'); button.type = 'button'; button.className = 'text-red-400 hover:text-red-600 ml-2'; button.setAttribute('aria-label', `Hapus TP ${tp.kode_tp || ''}`);
        const icon = document.createElement('i'); icon.className = 'fas fa-trash text-xs'; button.appendChild(icon);
        button.addEventListener('click', () => hapusTP(tpId(tp), tp.kode_tp || ''));
        row.append(content, button); list.appendChild(row);
    });
}

async function submitTP(event) {
    event.preventDefault();
    const mapel = document.getElementById('input-tp-mapel').value;
    const semester = document.getElementById('input-tp-smt').value;
    const kode = document.getElementById('input-tp-kode').value.trim();
    const deskripsi = document.getElementById('input-tp-desc').value.trim();
    if (!kode || !deskripsi) return toast('Kode dan deskripsi TP wajib diisi.', 'warning');
    if (!gradeSubjectAllowed(mapel)) return toast('Role ini hanya diizinkan mengelola Pelajaran PJOK.', 'error');

    const duplicate = state.mapelTP.some((tp) => tp.mapel === mapel && String(tp.semester) === String(semester) && String(tp.kode_tp).toLowerCase() === kode.toLowerCase());
    if (duplicate) return toast('Kode TP sudah digunakan pada mapel dan semester yang sama.', 'warning');

    const id = typeof crypto?.randomUUID === 'function' ? `tp_${crypto.randomUUID()}` : `tp_${Date.now()}`;
    const payload = { ID_mapel: id, mapel, semester, kode_tp: kode, deskripsi_tp: deskripsi };
    const result = await dbSet(`Mapel_TP/${safeFirebaseKey(id, 'ID TP')}`, payload);
    if (result?.ok) event.target.reset();
}

function updateTPDropdown() {
    const mapel = document.getElementById('filter-mapel-nilai')?.value;
    const select = document.getElementById('filter-tp-nilai');
    if (!select) return;
    applyGradeSubjectPolicy();
    const candidates = mapel ? visibleLearningObjectives().filter((tp) => tp.mapel === mapel) : [];
    select.innerHTML = mapel
        ? '<option value="">-- Pilih TP yang akan diisi --</option>' + candidates.map((tp) => `<option value="${escapeHTML(tpId(tp))}">${escapeHTML(tp.kode_tp)} - ${escapeHTML(tp.deskripsi_tp).substring(0, 70)}</option>`).join('')
        : '<option value="">Pilih Mapel Dahulu</option>';
    renderNilaiGrid();
}

function renderNilaiGrid() {
    const selectedTpId = document.getElementById('filter-tp-nilai')?.value;
    const container = document.getElementById('nilai-grid-container');
    const empty = document.getElementById('nilai-empty-state');
    if (container) container.classList.toggle('hidden', !selectedTpId);
    if (empty) empty.classList.toggle('hidden', !!selectedTpId);
    if (!selectedTpId) return;

    const tp = getTPById(selectedTpId);
    const body = document.getElementById('nilai-table-body');
    if (!tp || !body || !gradeSubjectAllowed(tp.mapel)) return;

    const currentKelas = typeof state !== 'undefined' && state.activeKelas ? state.activeKelas : '';

    body.innerHTML = [...state.students]
        .filter(student => currentKelas === '' || student.Kelas === currentKelas)
        .sort((a, b) => (a['Nama Lengkap'] || '').localeCompare(b['Nama Lengkap'] || ''))
        .map((student, index) => {
            const grade = state.nilaiTP.find((item) => (item.ID_Siswa || item.NISN) === (student.ID_Siswa || student.NISN) && gradeMatchesTP(item, tp));
        return `<tr class="hover:bg-slate-50 dark:hover:bg-[#111111] transition-colors"><td class="p-4 text-xs font-bold text-slate-400">${index + 1}</td><td class="p-4 font-bold text-sm">${escapeHTML(student['Nama Lengkap'])}<input type="hidden" class="n-nisn" data-student-id="${escapeHTML(student.ID_Siswa || student.NISN)}" value="${escapeHTML(student.NISN)}"><input type="hidden" class="n-nm" value="${escapeHTML(student['Nama Lengkap'])}"></td><td class="p-4 text-center"><input type="number" min="0" max="100" class="n-scr w-20 p-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-black text-center rounded-lg font-bold focus:ring-2 focus:ring-primary focus:outline-none" value="${grade?.nilai !== undefined ? escapeHTML(grade.nilai) : ''}"></td></tr>`;
    }).join('');
}

async function saveNilaiBatch() {
    const selectedTpId = document.getElementById('filter-tp-nilai')?.value;
    const tp = getTPById(selectedTpId);
    if (!tp) return toast('Pilih TP terlebih dahulu.', 'warning');
    if (!gradeSubjectAllowed(tp.mapel)) return toast('Role ini hanya diizinkan menyimpan nilai PJOK.', 'error');

    const updates = {};
    document.querySelectorAll('#nilai-table-body tr').forEach((row) => {
        const scoreRaw = row.querySelector('.n-scr')?.value;
        const nisn = row.querySelector('.n-nisn')?.value;
        const studentId = row.querySelector('.n-nisn')?.dataset.studentId || nisn;
        const student = { ID_Siswa: studentId, NISN: nisn };
        const id = gradeIdFor(student, tp);
        const existing = state.nilaiTP.find((item) => (item.ID_Siswa || item.NISN) === studentId && gradeMatchesTP(item, tp));

        if (scoreRaw !== '') {
            const score = Number(scoreRaw);
            if (!Number.isFinite(score) || score < 0 || score > 100) throw new Error(`Nilai ${nisn} harus 0-100.`);
            updates[`Nilai_TP/${id}`] = {
                ID_Nilai: id,
                ID_Siswa: studentId,
                NISN: nisn,
                nama: row.querySelector('.n-nm')?.value || '',
                learningObjectiveId: tpId(tp),
                mapel: tp.mapel,
                semester: String(tp.semester),
                kode_tp: tp.kode_tp,
                Deskripsi_TP: tp.kode_tp,
                tanggal: getJakartaDateString(),
                nilai: score,
                Kelas: typeof state !== 'undefined' && state.activeKelas ? state.activeKelas : ''
            };
            if (existing?.ID_Nilai && existing.ID_Nilai !== id) updates[`Nilai_TP/${safeFirebaseKey(existing.ID_Nilai, 'ID nilai lama')}`] = null;
        } else if (existing) {
            updates[`Nilai_TP/${safeFirebaseKey(existing.ID_Nilai || id, 'ID nilai')}`] = null;
        }
    });

    if (!Object.keys(updates).length) return toast('Tidak ada data yang diproses.', 'info');
    try {
        const result = await dbUpdate(updates);
        if (!result?.ok) throw result?.error || new Error('Nilai gagal disimpan.');
    } catch (error) {
        toast(error.message || String(error), 'error');
    }
}

function updateRekapTPDropdown() {
    const mapel = document.getElementById('rekap-mapel-nilai')?.value;
    const select = document.getElementById('rekap-tp-nilai');
    if (!select) return;
    applyGradeSubjectPolicy();
    const visible = visibleLearningObjectives();
    const candidates = mapel ? visible.filter((tp) => tp.mapel === mapel) : visible;
    select.innerHTML = '<option value="">Semua TP</option>' + candidates.map((tp) => `<option value="${escapeHTML(tpId(tp))}">${escapeHTML(tp.kode_tp)} · ${escapeHTML(tp.mapel)} · Smt.${escapeHTML(tp.semester)}</option>`).join('');
    renderRekapNilai();
}

function renderRekapNilai() {
    const mapel = document.getElementById('rekap-mapel-nilai')?.value;
    const selectedTpId = document.getElementById('rekap-tp-nilai')?.value;
    const nisn = document.getElementById('rekap-siswa-nilai')?.value;
    const body = document.getElementById('rekap-nilai-body');
    if (!body) return;

    let targetTPs = mapel ? visibleLearningObjectives().filter((tp) => tp.mapel === mapel) : visibleLearningObjectives();
    if (selectedTpId) targetTPs = targetTPs.filter((tp) => tpId(tp) === selectedTpId);
    const currentKelas = typeof state !== 'undefined' && state.activeKelas ? state.activeKelas : '';
    let filteredStudents = state.students;
    if (currentKelas) filteredStudents = filteredStudents.filter(s => s.Kelas === currentKelas);
    const students = nisn ? filteredStudents.filter((student) => student.NISN === nisn) : filteredStudents;
    const rows = [];

    [...students].sort((a, b) => (a['Nama Lengkap'] || '').localeCompare(b['Nama Lengkap'] || '')).forEach((student) => {
        targetTPs.forEach((tp) => {
            const grade = state.nilaiTP.find((item) => (item.ID_Siswa || item.NISN) === (student.ID_Siswa || student.NISN) && gradeMatchesTP(item, tp));
            if (!grade || grade.nilai === undefined) return;
            rows.push(`<tr><td class="p-4 font-bold text-sm whitespace-nowrap">${escapeHTML(student['Nama Lengkap'])}</td><td class="p-4 text-xs uppercase font-bold text-slate-500 whitespace-nowrap">${escapeHTML(tp.mapel)}</td><td class="p-4 font-bold text-primary whitespace-nowrap">${escapeHTML(tp.kode_tp)}</td><td class="p-4 text-[10px] italic max-w-xs truncate" title="${escapeHTML(tp.deskripsi_tp)}">${escapeHTML(tp.deskripsi_tp)}</td><td class="p-4 font-bold text-center text-lg">${escapeHTML(grade.nilai)}</td></tr>`);
        });
    });

    body.innerHTML = rows.join('') || '<tr><td colspan="5" class="p-8 text-center text-slate-400">Tidak ada data nilai sesuai filter.</td></tr>';
}

function renderBukuInduk() {
    const nisn = document.getElementById('induk-siswa-select')?.value;
    const container = document.getElementById('induk-content-area');
    if (!container) return;
    if (!nisn) {
        container.innerHTML = '<div class="p-8 text-center text-slate-400 absolute inset-0 flex flex-col items-center justify-center"><i class="fas fa-user-graduate text-6xl opacity-50 mb-4"></i><p class="font-bold">Pilih Siswa Terlebih Dahulu</p></div>';
        return;
    }

    const student = state.students.find((item) => item.NISN === nisn);
    if (!student) return;
    const attendance = state.presensi.filter((item) => item.NISN === nisn);
    const count = (status) => attendance.filter((item) => String(item.Status || '').toUpperCase() === status).length;
    const rows = [];

    const mapelList = [...new Set(visibleLearningObjectives().map((tp) => tp.mapel).filter(Boolean))];
    mapelList.forEach((mapel) => {
        const objectives = visibleLearningObjectives().filter((tp) => tp.mapel === mapel);
        const grades = objectives.map((tp) => ({ tp, grade: state.nilaiTP.find((item) => (item.ID_Siswa || item.NISN) === (student.ID_Siswa || student.NISN) && gradeMatchesTP(item, tp)) })).filter((item) => item.grade?.nilai !== undefined);
        if (!grades.length) return;
        const average = Math.round(grades.reduce((sum, item) => sum + Number(item.grade.nilai || 0), 0) / grades.length);
        const sorted = [...grades].sort((a, b) => Number(b.grade.nilai) - Number(a.grade.nilai));
        const top = sorted[0]?.tp?.deskripsi_tp || 'pemahaman materi';
        const bottom = sorted[sorted.length - 1]?.tp?.deskripsi_tp || 'penguasaan konsep lanjutan';
        const description = `Menunjukkan pemahaman yang sangat baik dalam ${top}. ${top !== bottom ? `Perlu bimbingan lebih lanjut dalam ${bottom}.` : ''}`;
        rows.push(`<tr><td class="p-3 border border-slate-300 font-bold">${escapeHTML(mapel)}</td><td class="p-3 border border-slate-300 text-center font-bold">${average}</td><td class="p-3 border border-slate-300 text-xs">${escapeHTML(description)}</td></tr>`);
    });

    const photo = escapeHTML(safeHTTPSUrl(student['Foto URL'], `https://ui-avatars.com/api/?name=${encodeURIComponent(student['Nama Lengkap'])}&background=fff&color=000`));
    container.innerHTML = `<div class="p-8 bg-white text-slate-800" id="cetak-induk-area"><div class="text-center border-b-2 border-black pb-4 mb-6"><h2 class="text-2xl font-bold uppercase tracking-wider">Buku Induk Siswa</h2><p class="font-medium text-sm">Kelas ${escapeHTML(state.pengaturan.nama_kelas)} - Tahun Pelajaran ${escapeHTML(state.pengaturan.tahun_pelajaran)}</p></div><div class="flex gap-6 mb-8 bg-slate-50 p-4 rounded-xl border border-slate-200"><img src="${photo}" alt="Foto siswa" class="w-32 h-40 object-cover border-4 border-white shadow-sm rounded bg-white"><div class="text-sm flex-1"><table class="w-full mb-4"><tr><td class="w-32 py-1 text-slate-500 font-bold">Nama Lengkap</td><td class="py-1">: <span class="font-bold text-base">${escapeHTML(student['Nama Lengkap'])}</span></td></tr><tr><td class="py-1 text-slate-500 font-bold">NISN</td><td class="py-1">: ${escapeHTML(student.NISN)}</td></tr><tr><td class="py-1 text-slate-500 font-bold">Nama Panggilan</td><td class="py-1">: ${escapeHTML(student['Nama Panggilan'] || '-')}</td></tr><tr><td class="py-1 text-slate-500 font-bold">Kelompok</td><td class="py-1">: ${escapeHTML(student.Kelompok || '-')}</td></tr></table><div class="inline-flex gap-4 p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold shadow-sm"><span>Hadir: ${count('HADIR')}</span><span>Sakit: ${count('SAKIT')}</span><span>Izin: ${count('IZIN')}</span><span>Alpa: ${count('ALPA')}</span></div></div></div><h3 class="font-bold text-lg mb-3 border-b-2 border-primary pb-1 inline-block">Capaian Akademik</h3><table class="w-full text-left border-collapse border border-slate-300"><thead class="bg-slate-100"><tr><th class="p-3 border border-slate-300 w-1/4">Mata Pelajaran</th><th class="p-3 border border-slate-300 w-16 text-center">Nilai</th><th class="p-3 border border-slate-300">Deskripsi Capaian Pembelajaran</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
}

async function cetakBukuInduk() {
    const content = document.getElementById('cetak-induk-area');
    if (!content) return toast('Data profil induk tidak ditemukan!', 'error');
    if (typeof html2pdf !== 'function') return toast('Pustaka PDF belum tersedia. Muat ulang saat online.', 'error');
    const nisn = document.getElementById('induk-siswa-select')?.value;
    const student = state.students.find((item) => item.NISN === nisn);
    showLoad('Membuat PDF Buku Induk...');
    try {
        await html2pdf().set({
            margin: 0.5,
            filename: `${safeFilename(`Buku_Induk_${student?.['Nama Lengkap'] || 'Siswa'}`)}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        }).from(content).save();
    } catch (error) {
        console.error(error);
        toast(`Gagal membuat PDF Buku Induk: ${error.message || error}`, 'error');
    } finally {
        hideLoad();
    }
}
