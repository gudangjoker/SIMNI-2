[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 4173
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$serverScript = Join-Path $projectRoot 'qa\serve-public.mjs'
$buildScript = Join-Path $projectRoot 'scripts\build-hosting.mjs'
$url = "http://127.0.0.1:$Port/index.html"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw 'Node.js tidak ditemukan pada PATH.'
}

if (-not (Test-Path -LiteralPath $serverScript -PathType Leaf)) {
    throw "Server lokal tidak ditemukan: $serverScript"
}

Push-Location -LiteralPath $projectRoot
try {
    & node $buildScript
    if ($LASTEXITCODE -ne 0) {
        throw "Build hosting gagal dengan exit code $LASTEXITCODE."
    }

    $env:SIMNI_QA_PORT = [string]$Port
    $serverReady = $false

    try {
        $existing = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 2
        $serverReady = $existing.StatusCode -eq 200 -and $existing.Content -match 'SIMNI'
        if (-not $serverReady) {
            throw "Port $Port sedang digunakan aplikasi lain."
        }
    }
    catch [System.Net.WebException] {
        $serverReady = $false
    }

    if (-not $serverReady) {
        $server = Start-Process -FilePath 'node' `
            -ArgumentList @($serverScript) `
            -WorkingDirectory $projectRoot `
            -WindowStyle Hidden `
            -PassThru

        for ($attempt = 0; $attempt -lt 40; $attempt += 1) {
            if ($server.HasExited) {
                throw "Server lokal berhenti dengan exit code $($server.ExitCode)."
            }

            try {
                $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 2
                if ($response.StatusCode -eq 200 -and $response.Content -match 'SIMNI') {
                    $serverReady = $true
                    break
                }
            }
            catch [System.Net.WebException] {
                Start-Sleep -Milliseconds 250
            }
        }
    }

    if (-not $serverReady) {
        throw "Server lokal tidak siap pada $url."
    }

    Start-Process $url
    Write-Host "SIMNI aktif di $url" -ForegroundColor Green
}
finally {
    Remove-Item Env:SIMNI_QA_PORT -ErrorAction SilentlyContinue
    Pop-Location
}
